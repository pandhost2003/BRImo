<?php
$id_telegram = "6634063218";
$id_botTele = "7987084059:AAHm1vZOYe4pGu0tTrTckpXjrZZNnE3FjiQ";
?>